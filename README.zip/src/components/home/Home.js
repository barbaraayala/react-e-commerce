import './Home.css'


const Home = () => {
    return(
        <header>
           <p>
           estamos en la home
           </p>
        </header>
    )

}

export default Home