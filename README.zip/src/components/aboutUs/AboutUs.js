import './AboutUs.css'


const AboutUs = () => {
    return (
        <header>
           <p>
           AboutUs
           </p>
        </header>
    )

}

export default AboutUs