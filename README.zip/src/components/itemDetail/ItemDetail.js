import './ItemDetail.css'


const ItemDetail = () => {
    return(
        <header>
           <p>
           ItemDetail
           </p>
        </header>
    )

}

export default ItemDetail